Project Title and Description:
My game is a single player air hockey game. There are three difficulties the user can choose from: Easy, Medium, and Hard. The harder the difficulty, the faster the AI moves and the harder the AI hits the puck. There are also three game modes: Square Mode, Classic, and 1v2. Square Mode is a regular game of air hockey but the strikers are squares instead of circles. Classic mode is just a regular game of air hockey. 1v2 is a classic game of air hockey but this time you are against two AIs. The user plays the game until the AI scores three times. Then, the user has the option to play again or not. The game also stores the user's highest score.


Run Instructions:
The user should run the file Term Project.py


Shortcut Commands"
q to quit game and return to home screen